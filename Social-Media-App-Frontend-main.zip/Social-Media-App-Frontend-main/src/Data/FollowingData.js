import Fimg1 from "../assets/Following/img-1.jpg"
import Fimg2 from "../assets/Following/img-2.jpg"
import Fimg3 from "../assets/Following/img-3.jpg"
import Fimg4 from "../assets/Following/img-4.jpg"
import Fimg5 from "../assets/Following/img-5.jpg"

export const FollowimgData =[
    {   
        name:"Mike Tysion",
        username:"@MrMikeTysion",
        img:Fimg1
    },
    {  
        name:"Violet",
        username:"@VioletBee",
        img:Fimg2
    },
    { 
        name:"Brandon",
        username:"@Brandon",
        img:Fimg3
    },
    {   
        name:"Lilly",
        username:"@LillyPrincess",
        img:Fimg4
    },
    {  
        name:"Camille",
        username:"@CamilleRose",
        img:Fimg5
    }
]