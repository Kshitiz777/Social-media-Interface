import img1 from "../assets/Post Images/img1.jpg"
import img2 from "../assets/Post Images/img2.jpg"
import img3 from "../assets/Post Images/img3.jpg"
import img4 from "../assets/Post Images/img4.jpg"
import img5 from "../assets/Post Images/img5.jpg"
import img6 from "../assets/Post Images/img6.jpg"


import DPimg1 from "../assets/DP/img1.jpg"
import DPimg2 from "../assets/DP/img2.jpg"
import DPimg3 from "../assets/DP/img3.jpg"
import DPimg4 from "../assets/DP/img4.jpg"
import DPimg5 from "../assets/DP/img5.jpg"
import DPimg6 from "../assets/DP/img6.jpg"


export const DisPlayPostData =[
    {
      username:"Harry",
      profilepicture:DPimg1,
      img:img1,
      datetime:"April 01, 2023 12:05 AM",
      body:"My 1st Post, Have A Good Day",
      like: 44,
      comment:10
    },
    {
      username:"chris dhaniel",
      profilepicture:DPimg2,
      img:img2,
      datetime:"May 01, 2023 12:05 AM",
      body:"My 2st Post, Have A Bad Day",
      like: 84,
      comment:50
    },
    {
      username:"April",
      profilepicture:DPimg3,
      img:img3,
      datetime:"June 01, 2023 12:05 AM",
      body:"My 3st Post, Have A Nice Day",
      like: 340,
      comment:76
    },
    {
      username:"Lara",
      profilepicture:DPimg4,
      img:img4,
      datetime:"July 01, 2023 12:05 AM",
      body:"My 4st Post, Have A Dull DayLorem ipsum dolor sit amet consectetur adipisicing elit. Iure veritatis numquam, ex explicabo tempore eum autem. Distinctio, odit fugiat rerum animi mollitia placeat? At ipsam debitis animi rem suscipit dicta dolor eveniet impedit minus. Quidem odit autem quia facere consectetur vero placeat delectus enim aspernatur",
      like: 44,
      comment:10
    },
    {

      username:"Kenny",
      profilepicture:DPimg5,
      img:img5,
      datetime:"February 01, 2023 12:05 AM",
      body:"My 5st Post, Have A Awesome Day",
      like: 30,
      comment:10
    },
    {
      username:"Reyana",
      profilepicture:DPimg6,
      img:img6,
      datetime:"January 01, 2023 12:05 AM",
      body:"My 6st Post, Have A Half Day",
      like: 844,
      comment:550
    }
  ]